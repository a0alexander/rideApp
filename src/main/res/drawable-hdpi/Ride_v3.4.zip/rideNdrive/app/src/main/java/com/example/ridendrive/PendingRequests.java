package com.example.ridendrive;

public class PendingRequests {


    String accepted;


    public PendingRequests(String accepted) {
        this.accepted = accepted;
    }

    public PendingRequests() {

    }


    public String getAccepted() {
        return accepted;
    }

    public void setAccepted(String accepted) {
        this.accepted = accepted;
    }
}
